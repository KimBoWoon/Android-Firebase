package com.example.tacademy.firebase;

/**
 * Created by Tacademy on 2016-10-10.
 */

public class FCMMsgModel {
    int age;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
