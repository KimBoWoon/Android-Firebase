package com.example.tacademy.firebase;

/**
 * Created by Tacademy on 2016-10-10.
 */

public class Contant {
    public static class RE {
        public static String APP_DOMAIN = "APP_DOMAIN";
        public static String APP_CNT = "APP_CNT";
        public static String APP_DEBUG = "APP_DEBUG";
    }
}
